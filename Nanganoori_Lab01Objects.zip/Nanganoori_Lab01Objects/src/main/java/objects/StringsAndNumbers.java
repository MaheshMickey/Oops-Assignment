/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package objects;
import java.util.Random;

/**
 *
 * @author Mahesh Kumar Nanganoori
 */
public class StringsAndNumbers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String string1 = "  Welcome    ";
        String string2 = " to ";
        String string3 = "  the first    ";
        String string4 = "Lab Activity ";
        String string5 = " in the   ";
        String string6 = " OOP Course ";
        String lenoffirststring = string1+string2+string3+string4+string5+string6;
      
        String strings1 = string1.trim();
        String strings2 = string2.trim();
        String strings3 = string3.trim();
        String strings4 = string4.trim();
        String strings5 = string5.trim();
        String strings6 = string6.trim();
        String lenoffsecondstring= strings1+" "+strings2+" "+strings3+" "+strings4+" "+strings5+" "+strings6;
     
        /**
         * Objects 2 initialization
         */
        String string2a = "lab interesting activities are activities lab Interesting Lab Activities Are Interesting Lab activities Lab Interesting";
        String string2b = "Object-Oriented-Programming 44542";
        String string2c1 = "Computer";
        String string2c2 = "Science";
        
        /**
         * Objects 3 initialization
         */  
       int value1 = 9;
       int value2 = 13;
       int myNumber = 27;
       int myNumber1 = 45;
       int myNumber2 = 27;
       
       /**
        * Objects 4 initialization
        * Instance of a First Random class
        */
       Random randominstance = new Random();
       int firstrandom = randominstance.nextInt(200);
       int secondrandom = randominstance.nextInt(200);
       int thirdrandom = randominstance.nextInt(200);
       int fourthrandom = randominstance.nextInt(200);
       int fifthrandom = randominstance.nextInt();
       int sixthrandom = randominstance.nextInt();
       int seventhrandom = randominstance.nextInt();
       
       
       
       //  Instance of a Second Random class
        long seed =30;
        randominstance.setSeed(seed);
        int Secfirstrandom1 = randominstance.nextInt(200);
        int Secsecondrandom1 = randominstance.nextInt(200);
        int Secthirdrandom1 = randominstance.nextInt(200);
        int Secfourthrandom1 = randominstance.nextInt(200);
        int Secfifthrandom1 = randominstance.nextInt();
        int Secsixthrandom1 = randominstance.nextInt();
        int Secseventhrandom1 = randominstance.nextInt();
        
        
        System.out.println("******** String Class ********\n");
        //  1(b)
        System.out.println(lenoffirststring);
        
        System.out.println("The length of the concatenated string is: "+lenoffirststring.length());
        //  1(c)
        System.out.println(lenoffsecondstring+"!");
        
        System.out.println("Length of the above string is: "+lenoffsecondstring.length());
        //  1(d)
        System.out.println("Retrieved: "+lenoffsecondstring.substring(21,33));
        //  1(e)
        System.out.println("Index of first I in "+lenoffsecondstring.substring(21,33).toUpperCase()+" is at :"+lenoffsecondstring.substring(21,33).toUpperCase().indexOf("I"));
        
        //  2(a)
        System.out.println("First occurrence of Interesting is at: "+string2a.indexOf("Interesting"));
        
        //  2(b)
        System.out.println(string2b);
        
        System.out.println(string2b.replaceAll("-", "_").replace(" ","-"));
        
        //  2(c)
        System.out.println("The ID is: "+string2c1.substring(0,4)+string2c2.substring(0, 3).toUpperCase()+string2c1.length()+string2c2.length());
       
        //  2(d)
        System.out.println("Having a 2+years experience in the  IT industry, I know how good playing with these technologies.So having a master's degree in that area would give a lot of options to enhance your skills");
        
        System.out.println("\n******** Math Class ********\n");
        
        //  3(i)
        System.out.println("sqrt (value12 +value22): "+Math.sqrt((Math.pow(value1,2))+(Math.pow(value2,2))));
        
        //  3(ii)
        System.out.println("exp (9): "+Math.exp(value1));
        
        //  3(iii)
        System.out.println("sec (9): "+1/Math.cos(value1));
        
        //  3(iv)
        System.out.println("Cube root of 27.00: "+Math.cbrt(myNumber));
        
        System.out.println("Logarithm value is: "+Math.log(myNumber));
        
        //  3(v)
        System.out.println("tan 60° - tan 45° / (1 + tan 60° tan 45°) = "+(Math.tan(60)-Math.tan(45))/(1+((Math.tan(60))*(Math.tan(45)))));
        
        //  3(vi)
        System.out.println("Theoretical value of tan (90) is: "+Math.tan(90)+"\nCubic root of modulus value of tan (90) is: "+Math.abs(Math.cbrt(Math.tan(90))));
        
        //  3(vii)
        System.out.println("Cosecant of 30 is: "+(1/Math.sin(30)));
        
        System.out.println("Secant of 30 is: "+(1/Math.cos(30)));
        
        System.out.println("Minimum value in Cosec (30) and Sec (30) is: "+Math.min((1/Math.sin(30)),(1/Math.cos(30))));
        
        System.out.println("Maximum value in Cosec (30) and Sec (30) is: "+Math.max((1/Math.sin(30)),(1/Math.cos(30))));
        
        
        /**
         * 3(a)(viii) Cos and Tan of 2 variables with rounded values
         */
        System.out.println("Rounded Value of cos "+myNumber1+" is : "+Math.round(Math.cos(myNumber1)));
        
        System.out.println("Rounded Value of cos "+myNumber2+" is : "+Math.round(Math.cos(myNumber2)));
        
        System.out.println("Rounded Value of tan "+myNumber1+" is : "+Math.round(Math.tan(myNumber1)));
        
        System.out.println("Rounded Value of tan "+myNumber2+" is : "+Math.round(Math.tan(myNumber2)));
        
        /**
         * 3(b)Computing Equation
         */
         System.out.println("The value of given equation is: "+(Math.abs(8*(Math.cos(myNumber2))))*((Math.sqrt(Math.sqrt(Math.pow(7, 4)+8*6*7*5)))/Math.sqrt(Math.sqrt(Math.sqrt(Math.pow(5, 2)-(Math.pow(3,2)))))));
         
         
         System.out.println("\n******** Random Class ********\n");
         
         /**
          * 4(a) First Random Class with no Seed Value
          */
         System.out.println("4 pseudo-random integer values between 0 (inclusive) and 200 (exclusive)");
         
         System.out.println("First random integer value is: "+ firstrandom + " Square of "+firstrandom + " is: "+((int)Math.pow(firstrandom,2)));
         
         System.out.println("Second random integer value is: "+ secondrandom + " Square of "+secondrandom + " is: "+((int)Math.pow(secondrandom,2)));
         
         System.out.println("Third random integer value is: "+ thirdrandom + " Square of "+thirdrandom + " is: "+((int)Math.pow(thirdrandom,2)));
         
         System.out.println("Fourth random integer value is: "+ fourthrandom + " Square of "+fourthrandom + " is: "+((int)Math.pow(fourthrandom,2)));
         
         System.out.println("3 pseudo-random integer values without seed value and bounds");
         
         System.out.println("Fifth random integer value is: " + fifthrandom);
         
         System.out.println("Sixth random integer value is: " + sixthrandom);
         
         System.out.println("Seventh random integer value is: " + seventhrandom);
         
         /**
          * 4(b) Writing our Answer on random values 
          */
         System.out.println("After executing the program multiple times. Random values changed everytime");
         
         /**
          * 4(c) Second Random Class with Seed Value
          */ 
         System.out.println("4 pseudo-random integer values between 0 (inclusive) and 200 (exclusive)");
         
         System.out.println("First random integer value is: "+ Secfirstrandom1 + " Square of "+Secfirstrandom1 + " is: "+((int)Math.pow(Secfirstrandom1,2)));
         
         System.out.println("Second random integer value is: "+ Secsecondrandom1 + " Square of "+Secsecondrandom1 + " is: "+((int)Math.pow(Secsecondrandom1,2)));
         
         System.out.println("Third random integer value is: "+ Secthirdrandom1 + " Square of "+Secthirdrandom1 + " is: "+((int)Math.pow(Secthirdrandom1,2)));
         
         System.out.println("Fourth random integer value is: "+ Secfourthrandom1 + " Square of "+Secfourthrandom1 + " is: "+((int)Math.pow(Secfourthrandom1,2)));
         
         System.out.println("3 pseudo-random integer values without seed value and bounds");
         
         System.out.println("Fifth random integer value is: " + Secfifthrandom1);
         
         System.out.println("Sixth random integer value is: " + Secsixthrandom1);
         
         System.out.println("Seventh random integer value is: " + Secseventhrandom1);  
         
         /**
          * 4(d) Writing Answers after checking the results multiple times
          */
         System.out.println("Yes! After running the program multiple times,the results are same everytime");
         
         /**
          * 4(e) Writing our Answers on why Second Random Class displays constant values
          */
         System.out.println("Everytime when the program is executed, results of b) vary . But the results for d) remains constant because we used .setSeed() method from Random Class ");
    }

}

