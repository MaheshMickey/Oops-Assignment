/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.northwest.nanganoorieng01;

/**
 *
 * @author Mahesh Kumar Nanganoori
 */
public class Student {
    String firstName,lastName;
    double gpa;
    final double CONVERTER =  2.50;
    char period;
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    /**
     * Constructor with following parameters
     * @param firstName
     * @param lastName
     * @param gpa
     * @param period 
     */
    public Student(String firstName, String lastName, double gpa, char period) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gpa = gpa;
        this.period = period;
    }
    /**
     * Calculating the GPA with round()
     * @return 
     */
    public double relativeGpa()
    {
        return Math.round(gpa * CONVERTER);
    }

    @Override
    public String toString() {
       return   "" + firstName + " " + lastName+ "\'s" +" relative GPA on 10.0"+" pointer scale is " + (int)relativeGpa() + ".";
    }
    
    
    
}
