/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.northwest.nanganoorieng01;

/**
 *
 * @author Mahesh Kumar Nanganoori
 */
public class StudentDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Student stu = new Student("Mahesh Kumar", "Nanganoori",3.0,'a');
        System.out.println(stu.toString());
    }
    
}
