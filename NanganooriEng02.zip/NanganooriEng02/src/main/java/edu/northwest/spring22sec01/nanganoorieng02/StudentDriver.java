/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.northwest.spring22sec01.nanganoorieng02;

/**
 *
 * @author Mahesh Kumar Nanganoori
 */
public class StudentDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String firstName,lastName,program,sID,bio;
        double gpa;
        firstName = "MaheshKumar";
        lastName = "Nanganoori";
        gpa = 3.0;
        sID = "S546551";
        program = "Applied Computer Science";
         bio = "I'm a new student enrolled in Applied Computer science at NorthWest Missouri State University. I'm from India, i enjoy exploring new places.";
         
         System.out.format("%-10s","Name");
         System.out.format("%-25s",":" +firstName + "," +lastName);
         
         System.out.format("\t%-10s", "GPA");
         System.out.format(":%-1.2f", gpa);
        System.out.println("");
        
        System.out.format("%-10s","Program");
        System.out.format(":%-25s", program);
        
        System.out.format("\t%-10s", "StudentID");
        System.out.format("%-25s",":" +sID );
        System.out.format("");
         
         String Bio = String.format("\nBio: %-10s",bio);
         System.out.println(Bio);
         
         
    }
    
}
