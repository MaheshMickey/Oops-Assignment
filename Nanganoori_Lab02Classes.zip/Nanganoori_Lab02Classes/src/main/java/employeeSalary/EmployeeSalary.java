/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeeSalary;

/**
 *
 * @author Mahesh kumar Nanganoori
 */
public class EmployeeSalary {
    private double hourlyRate;
    private double insuranceRate;
    private double taxRate;
    private double pfRate;
    private final int HOURS=40;
    
    /**
     * Constructs a EmployeeSalary with parameters 
     * @param hourlyRate the cost rate per hour
     * @param insuranceRate the rate per month
     * @param taxRate the taxRate per month 
     * @param pfRate the provident fund Rate per month 
     */

    public EmployeeSalary(double hourlyRate, double insuranceRate, double taxRate, double pfRate) {
        this.hourlyRate = hourlyRate;
        this.insuranceRate = insuranceRate;
        this.taxRate = taxRate;
        this.pfRate = pfRate;
    }
    
    /**
     * Constructs a no-arg constructor
     */

    public EmployeeSalary() {
    }
    
    /**
     * Returns the hourRate calculated per hour
     * @return Returns the hour rate 
     */
    
    public double getHourlyRate() {
        return hourlyRate;
    }
    
    /**
     * Returns the insurance rate charged per month
     * @return Returns the insurance rate 
     */

    public double getInsuranceRate() {
        return insuranceRate;
    }
    
    /**
     * Returns the tax rate charged per month
     * @return Returns the tax rate 
     */

    public double getTaxRate() {
        return taxRate;
    }
    
    /**
     * Returns the provident funding rate which will deduct per month
     * @return Returns the provident funding rate 
     */

    public double getPfRate() {
        return pfRate;
    }
    
    /**
     * Returns working hours
     * @return Returns 40 HOURS as it is assigned as constant 
     */

    public int getHOURS() {
        return HOURS;
    }
    
    /**
     * Sets the hourlyRate of Employee 
     * @param hourlyRate the rate per hour
     */

    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }
    
    /**
     * Sets the insuranceRate of Employee
     * @param insuranceRate the rate per hour
     */

    public void setInsuranceRate(double insuranceRate) {
        this.insuranceRate = insuranceRate;
    }
    
    /**
     * Sets the taxRate of Employee
     * @param taxRate the rate of tax per hour
     */

    public void setTaxRate(double taxRate) {
        this.taxRate = taxRate;
    }
    
    /**
     * Sets the pfRate of Employee
     * @param pfRate the rate to be deducted for PF
     */

    public void setPfRate(double pfRate) {
        this.pfRate = pfRate;
    }
    
    /**
     * Method to calculate Employee Monthly Salary
     * @return Month salary calculated with number of weeks and working hours
     */
    
    public double calcMonthlySalary()
    {
        return hourlyRate*4*HOURS;
    }
    
    /**
     * Method to calculate Monthly Insurance of Employee
     * @return Monthly Insurance amount
     */
    
    public double calcMonthlyInsurance()
    {
       return calcMonthlySalary()*(insuranceRate)/100;
    }
    
    /**
     * Method to calculate Provident fund amount of Employee
     * @return Monthly Provident fund amount
     */
    
    public double calcMonthlyPfAmount(){
        return calcMonthlySalary()*pfRate/100;
    }
    
    /**
     * Method to Calculate Annual Gross Salary including bonus
     * @param bonus to include in annual salary
     * @return returns AnnualGrossSalary of Employee
     */
    
    public double calcAnnualGrossSalary(double bonus){
      return bonus+(calcMonthlySalary()*12);    
    }
    
    /**
     * Method to calculate Annual NetPay 
     * @param bonus included to calculate NetPay 
     * @return returns Annual Net pay of a Employee
     */
    
    public double calcAnnualNetPay(double bonus){
       return calcAnnualGrossSalary(bonus)-(calcAnnualGrossSalary(bonus)*taxRate/100)-calcMonthlyInsurance()*12-calcMonthlyPfAmount()*12;
    }
    
    /**
     * Method to print the output to console.
     * @param str to specify employee object
     * @return returns the string 
     */

    public String toString(String str) {
        return "The details of  "+str+" object are as follows:\n"+"hourlyRate: " + getHourlyRate() + ", " +"insuranceRate: "+ getInsuranceRate()  + ", "+ "taxRate: "+getTaxRate()+", "+"pfRate: "+ getPfRate()+ ", " +"HOURS:"+ HOURS;
    }   
}
