/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package employeeSalary;

import java.util.Scanner;

/**
 *
 * @author Mahesh kumar Nanganoori
 */
public class EmployeeSalaryDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
         EmployeeSalary empSalObj1 = new EmployeeSalary();
         EmployeeSalary empSalObj2 = new EmployeeSalary(); 
         
        System.out.println("Testing the EmployeeSalary class:");
        System.out.println("Enter the hourly pay rate of the Employee: $");
        empSalObj1.setHourlyRate(scan.nextDouble());
        System.out.println("Enter the insurance rate of the Employee in percentage: $");
        empSalObj1.setInsuranceRate(scan.nextDouble());
        System.out.println("Enter the tax rate of the Employee in percentage: $");
        empSalObj1.setTaxRate(scan.nextDouble());
        System.out.println("Enter the pf rate of the Employee in percentage: $");
        empSalObj1.setPfRate(scan.nextDouble());
        System.out.println("Enter the bonus of the Employee: $");
        double bonus;
        bonus = scan.nextDouble();
        System.out.println("");
        System.out.println(empSalObj1.toString("empSalObj1"));
        System.out.println("");
        System.out.println("The monthly salary of the Employee is: $" + empSalObj1.calcMonthlySalary());
        System.out.println("The monthly insurance of the Employee is: $" + empSalObj1.calcMonthlyInsurance());
        System.out.println("The monthly pf of the Employee is: $" + empSalObj1.calcMonthlyPfAmount());
        System.out.println("The annual gross salary of the Employee is:  $" + empSalObj1.calcAnnualGrossSalary(bonus));
        System.out.println("The gross annual net pay of the Employee is: $" + empSalObj1.calcAnnualNetPay(bonus));
        
        System.out.println("***************************************************************************");
            
        
        System.out.println(empSalObj2.toString("empSalObj2"));
        System.out.println("The monthly salary of the Employee is: $" + empSalObj2.calcMonthlySalary());
        System.out.println("The monthly insurance of the Employee is: $" + empSalObj2.calcMonthlyInsurance());
        System.out.println("The monthly pf of the Employee is: $" + empSalObj2.calcMonthlyPfAmount());
        System.out.println("The annual gross salary of the Employee is:  $" + empSalObj2.calcAnnualGrossSalary(bonus));
        System.out.println("The gross annual net pay of the Employee is: $" + empSalObj2.calcAnnualNetPay(bonus));
        
        System.out.println("Enter the new bonus of the Employee: $");
       double bonus1;
       bonus1 = scan.nextDouble();
       empSalObj2.setHourlyRate(35.0);
       empSalObj2.setInsuranceRate(12.50);
       empSalObj2.setTaxRate(11.45);
       empSalObj2.setPfRate(10.5);
       System.out.println(empSalObj2.toString("empSalObj2"));
      System.out.println("The monthly salary of the Employee is: $" + empSalObj2.calcMonthlySalary());
        System.out.println("The monthly insurance of the Employee is: $" + empSalObj2.calcMonthlyInsurance());
        System.out.println("The monthly pf of the Employee is: $" + empSalObj2.calcMonthlyPfAmount());
        System.out.println("The annual gross salary of the Employee is:  $" + empSalObj2.calcAnnualGrossSalary(bonus1));
        System.out.println("The gross annual net pay of the Employee is: $" + empSalObj2.calcAnnualNetPay(bonus1));
          
        
    }
    
}
