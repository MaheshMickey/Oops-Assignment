/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gadgets;

/**
 *
 * @author Mahesh kumar Nanganoori
 */
public class Laptop {
    private String laptopBrand;
    private String processor;
    private double display;
    private int hardDrive;
    private String operatingSystem;
    private boolean touch;

    public Laptop(String laptopBrand, String processor, double display, int hardDrive, String operatingSystem, boolean touch) {
        this.laptopBrand = laptopBrand;
        this.processor = processor;
        this.display = display;
        this.hardDrive = hardDrive;
        this.operatingSystem = operatingSystem;
        this.touch = touch;
    }

    public Laptop() {
        
    }

    public String getLaptopBrand() {
        return laptopBrand;
    }

    public String getProcessor() {
        return processor;
    }

    public double getDisplay() {
        return display;
    }

    public int getHardDrive() {
        return hardDrive;
    }

    public String getOperatingSystem() {
        return operatingSystem;
    }

    public boolean isTouch() {
        return touch;
    }

    public void setLaptopBrand(String laptopBrand) {
        this.laptopBrand = laptopBrand;
    }

    public void setProcessor(String processor) {
        this.processor = processor;
    }

    public void setDisplay(double display) {
        this.display = display;
    }

    public void setHardDrive(int hardDrive) {
        this.hardDrive = hardDrive;
    }

    public void setOperatingSystem(String operatingSystem) {
        this.operatingSystem = operatingSystem;
    }

    public void setTouch(boolean touch) {
        this.touch = touch;
    }

    @Override
    public String toString() {
        return "Laptop Brand: " + laptopBrand + "\nLaptop Processor: " + processor + "\nLaptop Operating System: " + operatingSystem + "\nLaptop Hard Drive: " + hardDrive + "\nLaptop Display: " + display + "\nLaptop Is Touch: " + touch;
    }
    
    
    
    
    
}
