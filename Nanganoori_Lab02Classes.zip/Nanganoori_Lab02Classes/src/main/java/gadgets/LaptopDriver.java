/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gadgets;

/**
 *
 * @author S546551
 */
public class LaptopDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    Laptop object1 = new Laptop("HP", "Intel Core i5", 12.4, 512, "windows", true);
        System.out.println("*Testing getter method on object1*");
        System.out.println("Laptop Brandis: "+object1.getLaptopBrand()+"\nName of the processor is: "+object1.getProcessor() + "\nOperating System name: " + object1.getOperatingSystem() +"\nHard Drive capacity in GB's: "+object1.getHardDrive() +"\nScreen Size: "+object1.getDisplay()+"\nis Touch: "+object1.isTouch());
        System.out.println("*Testing toString method on object1*");
        System.out.println(object1.toString());
        
        Laptop object2 = new Laptop();
        System.out.println("*Testing toString method on object2*");
        System.out.println(object2.toString());
        object2.setLaptopBrand("Apple");
        object2.setProcessor("Intel core i3");
        object2.setOperatingSystem("macOS Mojave");
        object2.setHardDrive(256);
        object2.setDisplay(10.5);
        object2.isTouch();
        System.out.println("*Testing toString method on object2*");
        System.out.println(object2.toString());
        System.out.println("*Testing toString method on object2*");
        System.out.println("Laptop Brandis: "+object2.getLaptopBrand()+"\nName of the processor is: "+object2.getProcessor() + "\nOperating System name: " + object2.getOperatingSystem() +"\nHard Drive capacity in GB's: "+object2.getHardDrive() +"\nScreen Size: "+object2.getDisplay()+"\nis Touch: "+object2.isTouch());
        
    }
    
}
